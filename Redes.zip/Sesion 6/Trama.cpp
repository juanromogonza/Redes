//AUTORES: JUAN ROMO GONZ�LEZ Y JAIME GONZ�LEZ NAVARE�O
//GRUPO L1 LUNES 8:30
#include "Trama.h"

void crearTramaControl( Trama_C_D &TC,HANDLE PuertoCOM,ofstream &flujo_log)
{

    printf("Ha elegido enviar una trama de control\n");
    printf("seleccionar trama de control a enviar:\n");
    if(flujo_log.is_open()){
        flujo_log<<"Ha elegido enviar una trama de control\n";
        flujo_log<<"seleccionar trama de control a enviar:\n";
    }
    char val=0;
    bool esc=false;
    bool flag=false;//BANDERA PARA QUE NO SE ELIGA UNA OPCION NO VALIDA

    while(!flag){
        printf("1: Trama ENQ:\n2: Trama EOT:\n3: Trama ACK:\n4: Trama NACK:\n");
        if(flujo_log.is_open()){
            flujo_log<<"1: Trama ENQ:\n2: Trama EOT:\n3: Trama ACK:\n4: Trama NACK:\n";
        }
        cin>>val;
        switch(val) //COMPARAMOS LAS OPCIONES DADAS PARA ELEGIR LA TRAMA
        {
        case '1':
            TC.C =05;
            flag=true;
            printf("Se ha elegido enviar la trama ENQ\n");
             if(flujo_log.is_open()){
                flujo_log<<"Se ha elegido enviar la trama ENQ\n";
            }
            break;
        case '2':
            TC.C =04;
            flag=true;
            printf("Se ha elegido enviar la trama EOT\n");
             if(flujo_log.is_open()){
                flujo_log<<"Se ha elegido enviar la trama EOT\n";
            }
            break;
        case '3':
            TC.C =06;
            flag=true;
            printf("Se ha elegido enviar la trama ACK\n");
             if(flujo_log.is_open()){
                flujo_log<<"Se ha elegido enviar la trama ACK\n";
            }
            break;
        case '4':
            TC.C =21;
            flag=true;
            printf("Se ha elegido enviar la trama NACK\n");
             if(flujo_log.is_open()){
                flujo_log<<"Se ha elegido enviar la trama NACK\n";
            }
            break;
        default:
            printf("ERROR elija una opcion correcta.\n");
            if(flujo_log.is_open()){
            flujo_log<<"ERROR elija una opcion correcta.\n";
        }

        }
     }
     if(!esc){
        //COLOCACION DE VALORES ESPECIFICOS PARA LA TRAMA
        TC.S=22;
        TC.D='T';
        TC.NT='0';
        //ENVIAMOS LA TRAMA
        EnviarCaracter(PuertoCOM,TC.S);
        EnviarCaracter(PuertoCOM,TC.D);
        EnviarCaracter(PuertoCOM,TC.C);
        EnviarCaracter(PuertoCOM,TC.NT);
     }
}



void enviarTramaDatos(Trama_C_D TD,HANDLE PuertoCOM){

     EnviarCaracter(PuertoCOM,TD.S);
     EnviarCaracter(PuertoCOM,TD.D);
     EnviarCaracter(PuertoCOM,TD.C);
     EnviarCaracter(PuertoCOM,TD.NT);
     EnviarCaracter(PuertoCOM,TD.L);
     EnviarCadena(PuertoCOM,TD.Datos,(int)TD.L);
     EnviarCaracter(PuertoCOM,TD.BCE);

}
unsigned char calculoBCE(char Datos[],int L){

    unsigned char BCEaux=( unsigned char)Datos[0];

    for(int i=1;i<L;i++){
        BCEaux=BCEaux^( unsigned char)Datos[i];//REALIZAMOS LA OPERACION LOGICA XOR PARA CALCULAR EL BCE, PARA ELLO TRANSFORMAMOS LOS CHAR DE DATOS EN UNSIGNED CHAR    (unsigned char)
    }
    if(BCEaux==0||BCEaux==255){//SI EL BCE VALE 1 O 255 LE ASIGNAMOS EL VALOR 1
        BCEaux=1;
    }
    return BCEaux;
}


void crearTramaError(Trama_C_D &tramaError,Trama_C_D tramaEnvio){
    strcpy(tramaError.Datos,tramaEnvio.Datos);
    tramaError.S=tramaEnvio.S;
    tramaError.D=tramaEnvio.D;
    tramaError.C=tramaEnvio.C;
    tramaError.NT=tramaEnvio.NT;
    tramaError.L=tramaEnvio.L;
    tramaError.BCE=tramaEnvio.BCE;
    tramaError.Datos[0]='�';

}

