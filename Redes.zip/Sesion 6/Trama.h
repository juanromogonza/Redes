//AUTORES: JUAN ROMO GONZ�LEZ Y JAIME GONZ�LEZ NAVARE�O
//GRUPO L1 LUNES 8:30
#ifndef TRAMA_H
#define TRAMA_H
#include "PuertoSerie.h"
#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <iostream>
#include <string.h>
#include <fstream>
struct Trama_C_D
{
 unsigned char S;
 unsigned char D;
 unsigned char C;
 unsigned char NT;
 unsigned char L;
 char Datos[255];
 unsigned char BCE;
};
void crearTramaControl( Trama_C_D &TC,HANDLE PuertoCOM,ofstream &flujo_log);
unsigned char calculoBCE(char Datos[],int L);
void enviarTramaDatos(Trama_C_D TD,HANDLE PuertoCOM);
void crearTramaError(Trama_C_D &tramaError,Trama_C_D tramaEnvio);

#endif // TRAMA_H
