//AUTORES: JUAN ROMO GONZ�LEZ Y JAIME GONZ�LEZ NAVARE�O
//GRUPO L1 LUNES 8:30
#ifndef PROCESARINFORMACION_H
#define PROCESARINFORMACION_H
#include "Protocolo_M_E.h"


int ImprimirCaracter(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m,ofstream &flujo_log_e);

void EnviarCaracter(char carE,int &cont,char mensaje[],Trama_C_D &TC,HANDLE PuertoCOM,int &campo,Trama_C_D &AUX,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &estaEnProtocolo,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m, ofstream &flujo_log_e);

void crearTramaDatos(char mensaje[],int cont,int &campo,Trama_C_D &tramaEnvio,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,Trama_C_D &tramaRecepcion,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m,ofstream &flujo_log_e);

void enviarFichero(Trama_C_D &tramaEnvio,HANDLE PuertoCOM,int &campo,Trama_C_D &tramaRecepcion,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo);

void enviarCuerpoFichero(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,ifstream &flujo_lectura,int &cont,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,Trama_C_D &tramaEnvio,ofstream &flujo_log,int &coloFichero,bool &esEscape,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m,ofstream &flujo_log_e);

void procesarFichero(int &cont_Fichero,Trama_C_D tramaRecepcion,HANDLE Pantalla,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,ofstream &flujo_log_Pro,bool esMaestro);

void crearTramaFichero(Trama_C_D &tramaEnvio,HANDLE PuertoCOM,char cadena_aux[]);

void soyEsclavo(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m, ofstream &flujo_log_e);

void soyMaestro(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m, ofstream &flujo_log_e);

void maestroSondeo(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m,ofstream &flujo_log_e);

void enviarFicheroProtocolo(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m,ofstream &flujo_log_e);

void maestroSeleccion(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m, ofstream &flujo_log_e);

void crearTramaFicheroProtocolo(Trama_C_D &tramaEnvio,HANDLE PuertoCOM,char cadena_aux[], int &nt);

void esclavoSelecion(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m,ofstream &flujo_log_e);

void esclavoSondeo(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m,ofstream &flujo_log_e);


#endif // PROCESARINFORMACION_H
