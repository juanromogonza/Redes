//AUTORES: JUAN ROMO GONZ�LEZ Y JAIME GONZ�LEZ NAVARE�O
//GRUPO L1 LUNES 8:30
#ifndef PROTOCOLO_M_E_H
#define PROTOCOLO_M_E_H
#include "Pantalla.h"

using namespace std;
void enviarLiberacionSeleccion(HANDLE PuertoCOM,ofstream &flujo_log_m);
void  aceptacionSelecion(HANDLE PuertoCOM,unsigned char nt,ofstream &flujo_log_e);
void aceptacionSondeo(HANDLE PuertoCOM,unsigned char nt,ofstream &flujo_log_e);
void liberacionSondeo(HANDLE PuertoCOM,int &nt,ofstream &flujo_log_e);
void ErrorSeleccion(HANDLE PuertoCOM,unsigned char nt,ofstream &flujo_log_e);
void ErrorSondeo(HANDLE PuertoCOM,unsigned char nt,ofstream &flujo_log_e);
#endif // PROTOCOLO_M_E_H
