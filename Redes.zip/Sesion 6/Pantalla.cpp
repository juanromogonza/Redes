//AUTORES: JUAN ROMO GONZ�LEZ Y JAIME GONZ�LEZ NAVARE�O
//GRUPO L1 LUNES 8:30
#include "Pantalla.h"
#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <iostream>
#include <string.h>



void pedirPuerto(char PSerie[]) {
bool flag=false;//BANDERA QUE INDICA SI SE HA ELEGIDO BIEN OPCION O NO
int val=0;
printf("seleccionar el puerto a utilizar:\n");
while(!flag){
    printf("1. COM1:\n2. COM2:\n3. COM3:\n4. COM4:\n");
    cin>>val;
    switch(val) //COMPARAMOS LAS OPCIONES DADAS PARA ELEGIR PUERTO
        {
    case 1:
        strcpy (PSerie,"COM1");
        printf("Se ha elegido el puerto COM1\n");
        flag=true;
    break;
    case 2:
        strcpy (PSerie,"COM2");
        printf("Se ha elegido el puerto COM2\n");
        flag=true;
    break;
    case 3:
        strcpy (PSerie,"COM3");
        printf("Se ha elegido el puerto COM3\n");
        flag=true;
    break;
    case 4:
        strcpy (PSerie,"COM4");
        printf("Se ha elegido el puerto COM4\n");
        flag=true;
    break;
    default:
        printf("ERROR elija una opcion correcta.\n");


        }
    }
 }

void cambiarColorPantalla(HANDLE Pantalla, int color){
    SetConsoleTextAttribute(Pantalla,color);
}

void pedirVelocidad(int &vel){
bool flag=false;//BANDERA QUE INDICA SI SE HA ELEGIDO BIEN OPCION O NO
printf("seleccionar la velocidad de transmision:\n");
while(!flag){
    printf("1. 1400:\n2. 2400:\n3. 4800:\n4. 9600:\n5. 19200\n");
    cin>>vel;
    switch(vel) //COMPARAMOS LAS OPCIONES DADAS PARA ELEGIR LA VELOCIDAD
        {
    case 1:
        vel=100;
        flag=true;
        printf("Se ha elegido la velocidad 1400\n");
    break;
    case 2:
        vel=2400;
        flag=true;
         printf("Se ha elegido la velocidad 2400\n");
    break;
    case 3:
        vel=4800;
        flag=true;
         printf("Se ha elegido la velocidad 4800\n");
    break;
    case 4:
        vel=9600;
        flag=true;
         printf("Se ha elegido la velocidad 9600\n");
    break;
    case 5:
        vel=19200;
        flag=true;
         printf("Se ha elegido la velocidad 19200\n");
    break;
    default:
        printf("ERROR elija una opcion correcta.\n");

        }
    }
}

void transformar(char trama[],Trama_C_D t){
  switch(t.C) //COMPARAMOS LAS OPCIONES DADAS PARA ELEGIR PUERTO
        {
    case 04:
        strcpy (trama,"EOT");
    break;
    case 05:
        strcpy (trama,"ENQ");

    break;
    case 06:
        strcpy (trama,"ACK");
    break;
    case 21:
        strcpy (trama,"NACK");
    break;
    default:
         strcpy (trama,"STX");


        }
}


bool elegirMaestro_Esclavo(){
    int eleccion;
    bool escogido;
    bool flag=false;
    printf("Selecione Maestro o Esclavo:\n");
    printf("1.Maestro\n");
    printf("2.Esclavo\n");
    while(!flag){
        cin>>eleccion;
        switch(eleccion){
        case 1:
            flag=true;
            escogido=true;
            break;
        case 2:
             printf("Se ha elegido la opcion Esclavo\n");
             flag=true;
             escogido=false;
            break;
        default:
            printf("Elija una opcion correcta\n");

        }
    }
    return escogido;

}


bool seleccionOpcionMaestro(ofstream &flujo_log_m,HANDLE Pantalla){
    int eleccion;
    bool escogido;
    bool flag=false;
    printf("Ha selecionado Maestro, selecione la operacion a realizar:\n");
    cambiarColorPantalla(Pantalla,169);
    printf("1.Seleccion\n");
    printf("2.Sondeo\n");
    if(flujo_log_m.is_open()){
        flujo_log_m<<"Ha selecionado Maestro, selecione la operacion a realizar:\n";
        flujo_log_m<<"1.Seleccion\n";
        flujo_log_m<<"2.Sondeo\n";
    }
    while(!flag){
        cin>>eleccion;
        switch(eleccion){
        case 1:

            flag=true;
            escogido=true;
            break;
        case 2:

             flag=true;
             escogido=false;
            break;
        default:
            printf("Elija una opcion correcta\n");
            if(flujo_log_m.is_open()){
                flujo_log_m<<"Elija una opcion correcta\n";
            }
        }
    }
    return escogido;

}
























