//AUTORES: JUAN ROMO GONZ�LEZ Y JAIME GONZ�LEZ NAVARE�O
//GRUPO L1 LUNES 8:30

#include "ProcesarInformacion.h"

using namespace std;

HANDLE PuertoCOM;
HANDLE Pantalla;

int main()
{
    Trama_C_D tramaEnvio,tramaRecepcion;
    Pantalla=GetStdHandle(STD_OUTPUT_HANDLE);//PARA CAMBIAR EL COLOR
    char carE;//VARIABLES PARA ALMACENAR LOS CARACTERES LEIDOS Y ENVIADOS
    char PSerie[5];//VARIABLE DONDE SE GUARDA EL NOMBRE DEL PUERTO ELEGIDO
    int vel=0;//VARIABLE USADA PARA ELEGIR LA FRECUENCIA DEL PUERTO
    int cont=0;//CONTADOR DEL NUMERO DE CARACTERES QUE SE VAN A ENVIAR EN EL MENSAJE
    int campo=1;//CONTADOR DE LA TRAMA ENVIADA
    char mensaje[802];// PONEMOS 802 POR QUE SI EL USUSARIO LLEGA AL TOPE DE 800 CARACTERES A ENVIAR A�ADIREMOS UN SALTO DE LINEA AL FINAL, COMO SI SE ESTUVISE TRATANDO DE LA TECLA F1
    bool esFichero=false;//LAS DOS VARIABLES QUE INDICAN CUANDO SE RECIBE UN FICHER
    bool finFichero=false;
    int colorFichero;
    int cont_Fichero=1;//CONTADOR QUE INDICA EN QUE PARTE DE LA RECEPCION DEL FICHERO ESTAMOS
    char cadena_AutoresRecepcion[70];//CADENA QUE ALMACENA LOS AUTORES EN LA RECEPCION
    ofstream flujo_escritura;//FLUJO DE ESCRITURA QUE SE USA PARA ESCRIBIR EN EL FICHERO DEL RECEPTOR
    ofstream flujo_log;//FLUJO DE ESCRITURA PARA ESCRIBIR EN EL LOG
    bool estaEnProtocolo=false;//INDICA SI SE HA ACTIVADO EL PROTOCOLO
    bool esMaestro=false;
    bool esEsclavo=false;
    ofstream flujo_log_m;
    ofstream flujo_log_e;
    bool esSondeo=false;
    //Encabezado
    printf("============================================================================\n");
    printf("----------- PRACTICAS DE FUNDAMENTOS DE REDES DE COMUNICACIONES ------------\n");
    printf("---------------------------- CURSO 2019/20 ---------------------------------\n");
    printf("----------------------------- SESION3.CPP ----------------------------------\n");
    printf("============================================================================\n\n");

    //Abrimos el puerto. Para ello necesitamos indicar los siguientes par�metros:
    // - Nombre del puerto a abrir: ("COM1", "COM2", "COM3", ...).
    // - Velocidad: (1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200).
    // - N�mero de bits en cada byte enviado o recibido: (4, 5, 6, 7, 8).
    // - Paridad: (0=sin paridad, 1=impar, 2=par, 3=marca, 4=espacio).
    // - Bits de stop: (0=1 bit, 1=1.5 bits, 2=2 bits).

    pedirPuerto(PSerie);//LLAMAMOS A UN METODO DE LA LIBRERIA PANTALLA EL CUAL SELECCIONA EL PUERTO QUE SE VA A ELEGIR
    pedirVelocidad(vel);//LLAMAMOS A UN METODO DE LA LIBRERIA PANTALLA EL CUAL SELECCIONA LA FRECUENCIA DEL PUERTO ELEGIDO ANTERIORMENTE
    PuertoCOM = AbrirPuerto(PSerie, vel, 8, 0, 0);//SE CREA EL PUERTO CON LOS DATOS ELEGIDOS

    //COMPROBAMOS SI SE HA CREADO EL PUERTO O NO
    if(PuertoCOM == NULL)
    {
        printf("Error al abrir el puerto %s\n",PSerie);
        getch();
        return (1);
    }
    else
        printf("Puerto %s abierto correctamente\n",PSerie);
        //cambiarColorPantalla(Pantalla,169);
    while(carE!=27)//HASTA QUE NO SE PULSE LA TECLA ESC NO SE ACABA EL PROGRAMA
    {

        ImprimirCaracter(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,colorFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);// LLAMAMOS AL MODULO PARA IMPRIMIR CARACTER


        if (kbhit()){
            carE = getch();//LEEMOS EL CARACTER ESCRITO EN PANTALLA PARA PODER TRATARLO
            if (carE != 27)
                    EnviarCaracter(carE,cont,mensaje,tramaEnvio,PuertoCOM,campo,tramaRecepcion,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,colorFichero,estaEnProtocolo,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);//LLAMAMOS AL MODULO PARA ENVIAR CARACTER
        }
    }
    flujo_log.close();
// CERRAMOS EL PUERTO
   CerrarPuerto(PuertoCOM);
   return 0;
}
