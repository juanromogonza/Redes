//AUTORES: JUAN ROMO GONZ�LEZ Y JAIME GONZ�LEZ NAVARE�O
//GRUPO L1 LUNES 8:30
#ifndef PANTALLA_H
#define PANTALLA_H
#include <windows.h>
#include "Trama.h"
using namespace std;

void pedirPuerto(char PSerie[]);
void pedirVelocidad(int &vel);
void cambiarColorPantalla(HANDLE Pantalla, int color);
void transformar(char trama[],Trama_C_D t);
bool elegirMaestro_Esclavo();
bool seleccionOpcionMaestro(ofstream &flujo_log_m,HANDLE Pantalla);
#endif // PANTALLA_H
