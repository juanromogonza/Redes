//AUTORES: JUAN ROMO GONZ�LEZ Y JAIME GONZ�LEZ NAVARE�O
//GRUPO L1 LUNES 8:30
#include "ProcesarInformacion.h"




int ImprimirCaracter(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla, bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo, bool &esSondeo,ofstream &flujo_log_m,ofstream &flujo_log_e)
{
        int resultado=0;
        char carR=0;
        carR = RecibirCaracter(PuertoCOM);//RECEPCION
        if (carR){
            switch(campo){
                // USAMOS CAMPO PARA ALMACENAR LA TRAMA DE FORMA CORRCECTA
            case 1:
                if(carR==22){
                    tramaRecepcion.S=carR;
                    campo++;
                }else{
                    if(carR=='{'){//INICIZLIZACION DE ENVIO DE FICHERO
                    cont_Fichero=1;
                    esFichero=true;
                    //bandera true indicando que inicia el fichero
                    }else{
                        if(carR=='}'){
                            flujo_escritura.close();
                                //FINALIZACION DE ENVIO DE FICHERO
                            cambiarColorPantalla(Pantalla,coloFichero);
                            printf("Fichero recibido\n");
                             if(flujo_log.is_open()){
                                flujo_log<<"Fichero recibido\n";
                             }else{
                                 if(!esSondeo){
                                        if(flujo_log_e.is_open()){
                                        flujo_log_e<<"Fichero recibido\n";
                                    }
                                 }else{
                                        if(flujo_log_m.is_open()){
                                        flujo_log_m<<"Fichero recibido\n";
                                    }
                                 }
                             }

                            esFichero=false;
                            finFichero=true;
                        }else{
                            if(carR=='M'){
                                if(esMaestro==false){
                                        esEsclavo=true;
                                    soyMaestro(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
                                }
                            }else{
                                if(carR=='E'){
                                     esMaestro=true;
                                    soyEsclavo(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
                                }
                            }
                        }
                    }
                }
            break;
            case 2:
                tramaRecepcion.D=carR;
                campo++;
                break;
            case 3:
                tramaRecepcion.C=carR;
                campo++;
                break;
            case 4:
                tramaRecepcion.NT=carR;
                if(tramaRecepcion.C!=02){//COMPROBAMOS SI ESTAMOS ANTE UNA TRAMA DE DATOS O DE CONTROL,SI ES DE CONTROL ENTRA EN EL IF
                    campo=1;//AL SER EL ULTIMO CARACTER DE LA TRAMA DE CONTROL SE COLOCA CAMPO A 1 PARA QUE VUELVA A LA NORMALIDAD
                    if(!esMaestro){
                        cambiarColorPantalla(Pantalla,240);//240 CAMBIAMOS EL COLOR E LETRA Y FONDO DE PANTALLA
                        }
                        switch(tramaRecepcion.C){
                    case 04:
                        resultado=04;
                        if(!esMaestro){
                            printf("Se ha recibido una trama EOT\n");
                                if(flujo_log.is_open()){
                                    flujo_log<<"Se ha recibido una trama EOT\n";
                                }
                        }
                        break;
                    case 05:
                        resultado=05;
                        if(!esMaestro){
                            printf("Se ha recibido una trama ENQ\n");
                                if(flujo_log.is_open()){
                                    flujo_log<<"Se ha recibido una trama ENQ\n";
                                }
                        }
                        break;
                    case 06:
                            resultado=06;


                            if(!esMaestro){
                            printf("Se ha recibido una trama ACK\n");
                                if(flujo_log.is_open()){
                                    flujo_log<<"Se ha recibido una trama ACK\n";
                                }
                            }

                        break;
                    case 21:
                        resultado=21;
                        if(!esMaestro){
                            printf("Se ha recibido una trama NACK\n");
                                if(flujo_log.is_open()){
                                    flujo_log<<"Se ha recibido una trama NACK\n";
                                }
                        }
                        break;
                        }
                    }else{//AL SER TRAMA DE DATOS NO ACABA EL SWITCH Y SIGUE AUMENTANDO PARA SEGUIR ALMACENANDO LA TRAMA
                        campo++;
                    }
                break;
            case 5://NO PONEMOS BREAK PARA QUE ENTRE AL SIGUIENTE CAMPO
                tramaRecepcion.L=carR;
                campo++;
            case 6:
                RecibirCadena(PuertoCOM,tramaRecepcion.Datos,tramaRecepcion.L);//USAMOS RECIBIR CADENA PARA OBTENER TODA LA CADENA DE GOLPE, tramaRecepcion.DATOS ANTES ESTABA VACIO Y AL LLAMAR SE LLENA CON LA CADENA
                tramaRecepcion.Datos[tramaRecepcion.L]='\0';
                campo++;
                break;
            case 7://PONEMOS CAMO A 1 POR SE ACABA LA TRAMA DE DATOS Y REINICIAMOS CAMPO
                tramaRecepcion.BCE=carR;
                campo=1;
                if(tramaRecepcion.BCE==calculoBCE(tramaRecepcion.Datos,tramaRecepcion.L)){
                        resultado=02;//COMPROBAMOS SI EL BCE ENVIADO ES EL MISMO QUE EL RECIBIDO, SI NO ES AS� DA ERROR
                       if(esFichero){
                            resultado=02;
                            if(!esSondeo){

                                procesarFichero(cont_Fichero,tramaRecepcion,Pantalla,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,flujo_log_e,esMaestro);//PROCESAMOS LA INFORMACION RECIBIDA POR EL FICHERO
                            }else{

                                procesarFichero(cont_Fichero,tramaRecepcion,Pantalla,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,flujo_log_m,esMaestro);//PROCESAMOS LA INFORMACION RECIBIDA POR EL FICHERO
                            }
                       }else{
                            if(finFichero){
                                    resultado=02;
                                    cambiarColorPantalla(Pantalla,coloFichero);
                                 cout<<"El fichero recibido tiene un tama�o de bytes: "<<tramaRecepcion.Datos<<endl;
                                  if(flujo_log.is_open()){
                                        flujo_log<<"El fichero recibido tiene un tama�o de bytes: ";
                                        flujo_log<<tramaRecepcion.Datos;
                                        flujo_log<<"\n";
                                    }else{
                                        if(!esSondeo){
                                            if(flujo_log_e.is_open()){
                                                flujo_log_e<<"El fichero recibido tiene un tama�o de bytes: ";
                                                flujo_log_e<<tramaRecepcion.Datos;
                                                flujo_log_e<<"\n";
                                            }
                                        }else{
                                            if(flujo_log_m.is_open()){
                                                flujo_log_m<<"El fichero recibido tiene un tama�o de bytes: ";
                                                flujo_log_m<<tramaRecepcion.Datos;
                                                flujo_log_m<<"\n";
                                            }
                                        }
                                    }
                                finFichero=false;
                                cambiarColorPantalla(Pantalla,169);
                                if(esMaestro){
                                    cambiarColorPantalla(Pantalla,7);
                                }
                            }else{
                                cambiarColorPantalla(Pantalla,240);//240 CAMBIAMOS EL COLOR E LETRA Y FONDO DE PANTALLA
                                cout<<tramaRecepcion.Datos;//IMPRIMIR POR PANTALLA EL MENSAJE
                                if(flujo_log.is_open()){
                            flujo_log<<tramaRecepcion.Datos;
                        }
                            }
                       }
                }else{
                    if(esFichero){
                        resultado=21;
                        if(!esMaestro){
                            printf("Error en la recepci�n de la trama del fichero.\n");
                            if(flujo_log.is_open()){
                                flujo_log<<"Error en la recepci�n de la trama del fichero.\n ";
                            }
                        }
                    }else{
                       printf("Error al recibir la trama\n");
                       cout<<tramaRecepcion.Datos;//IMPRIMIR POR PANTALLA EL MENSAJE
                        cout<<endl;
                        printf("%u\n",tramaRecepcion.BCE);
                        if(flujo_log.is_open()){
                            flujo_log<<"Error al recibir la trama\n ";
                        }
                    }
                }
                break;
            }

    }
    return resultado;

}
void procesarFichero(int &cont_Fichero,Trama_C_D tramaRecepcion,HANDLE Pantalla,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,ofstream &flujo_log_Pro, bool esMaestro){
    switch (cont_Fichero){
    case 1:
        if(esMaestro){
          cambiarColorPantalla(Pantalla,12);
        }
        cont_Fichero++;
        sprintf(cadena_AutoresRecepcion,tramaRecepcion.Datos);//GUARDAMOS EN cadena_AutoresRecepcion EL NOMBRE DE LOS AUTORES
        break;
    case 2:

        cont_Fichero++;
        coloFichero=atoi(tramaRecepcion.Datos);
         if(esMaestro){
          cambiarColorPantalla(Pantalla,12);
        }
        break;
    case 3:

        cont_Fichero++;
        if(!esMaestro){
        cambiarColorPantalla(Pantalla,coloFichero);//CAMBIAMOS EL COLOR PREDETERMINADO POR EL QUE NOS OFRECE EL FICHERO
        printf("Recibiendo fichero por %s.\n", cadena_AutoresRecepcion);//SE MUESTRA �N LOS AUTORES QUE ESCRIBEN EL FICHERO
        }
         if(flujo_log.is_open()){
                flujo_log<<"Recibiendo fichero por ";
                flujo_log<<cadena_AutoresRecepcion;
                flujo_log<<"\n";
            }
		flujo_escritura.open(tramaRecepcion.Datos);//ABRIMOS EL FICHERO CON EL NOMBRE QUE NOS PASAN EN tramaRecepcion.Datos
        break;
    default:
        if (flujo_escritura.is_open()) {
                flujo_escritura<<tramaRecepcion.Datos;//ESCRIBIMOS LA INFORMACION DENTRO DEL FICHERO
		}else{
		    printf("ERROR AL ABRIR FICHERO\n");
		    if(flujo_log.is_open()){
                flujo_log<<"ERROR AL ABRIR FICHERO\n";
            }else{
                if(flujo_log_Pro.is_open()){
                    flujo_log_Pro<<"ERROR AL ABRIR FICHERO\n";
                }
            }
		}
		if(esMaestro){
          cambiarColorPantalla(Pantalla,2);
        }
    }

}


void crearTramaFicheroProtocolo(Trama_C_D &tramaEnvio,HANDLE PuertoCOM,char cadena_aux[], int &nt, unsigned char d){
tramaEnvio.S=' ';
tramaEnvio.C=' ';
tramaEnvio.D=' ';
tramaEnvio.L=' ';
tramaEnvio.NT=' ';
tramaEnvio.BCE=' ';
for(int i=0;i<255;i++){
    tramaEnvio.Datos[i]=' ';
}
 tramaEnvio.S=22;
    tramaEnvio.D=d;
    tramaEnvio.C=02;
    if(nt==0){
        nt=1;
        tramaEnvio.NT='1';
    }else{
        nt=0;
        tramaEnvio.NT='0';
    }
    tramaEnvio.L=strlen(cadena_aux);
    strcpy(tramaEnvio.Datos,cadena_aux);
    tramaEnvio.BCE=calculoBCE(tramaEnvio.Datos,(int)tramaEnvio.L);
}
void enviarFicheroProtocolo(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m,ofstream &flujo_log_e){
    unsigned char T1='T';
    unsigned char R1='R';
    char tramaPantalla[5];
    int nt=1;
    int contError=0;
    int espera=0;
    Trama_C_D tramaEnvio;
    Trama_C_D tramaError;
    char cadena_aux[70];
    char cadena_Autores[70];
    int cont =0;
    char carE;
    bool esEscape=false;
    //CREACION DE VARIABLES

    cambiarColorPantalla(Pantalla,12);
    ifstream flujo_lectura;
    flujo_lectura.open("Eprotoc.txt");
    if(flujo_lectura.is_open()){
        EnviarCaracter(PuertoCOM,'{');//MANDAMOS CARACTER DE INICIO FICHERO
        for(int i =0;i<3;i++){//ENVIAR LAS 3 PRIMERAS LINEAS, OSEA, LA CABECERA
          flujo_lectura.getline(cadena_aux,70);
          if(i==0){
           strcpy(cadena_Autores,cadena_aux);//EN CADENA_AUTORES SE GUARDA CADENA_AUX
          }
            if(!esSondeo){//COMPROBACION DE SI ESTAMOS EN SONDE O SELECCION
                crearTramaFicheroProtocolo(tramaEnvio,PuertoCOM,cadena_aux,nt,R1);
                enviarTramaDatos(tramaEnvio,PuertoCOM);
                 transformar(tramaPantalla,tramaEnvio);
                printf("E %c %s %c %u\n",R1,tramaPantalla,tramaEnvio.NT,tramaEnvio.BCE);
                 if(flujo_log_m.is_open()){
                    flujo_log_m<<"E "<<R1<<" "<<tramaPantalla<<" "<<tramaEnvio.NT<<" "<<(int)tramaEnvio.BCE<<"\n";
                }
            }else{
                crearTramaFicheroProtocolo(tramaEnvio,PuertoCOM,cadena_aux,nt,T1);
                enviarTramaDatos(tramaEnvio,PuertoCOM);
                transformar(tramaPantalla,tramaEnvio);
                printf("E %c %s %c %u\n",T1,tramaPantalla,tramaEnvio.NT,tramaEnvio.BCE);
                if(flujo_log_e.is_open()){
                    flujo_log_e<<"E "<<T1<<" "<<tramaPantalla<<" "<<tramaEnvio.NT<<" "<<(int)tramaEnvio.BCE<<"\n";
                }
            }
             espera=0;
             while(espera!=06){//ESPERA DE RESPUESTA ACK PARA SEGUIR ENVIANDO INFORMACION
                espera=ImprimirCaracter(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
                if(espera==06){
                    if(!esSondeo){
                        transformar(tramaPantalla,tramaRecepcion);
                        printf("R %c %s %c\n",R1,tramaPantalla,tramaRecepcion.NT);
                        if(flujo_log_m.is_open()){
                            flujo_log_m<<"R "<<R1<<" "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
                        }
                    }else{
                        transformar(tramaPantalla,tramaRecepcion);
                        printf("R %c %s %c\n",T1,tramaPantalla,tramaRecepcion.NT);
                        if(flujo_log_e.is_open()){
                            flujo_log_e<<"R "<<T1<<" "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
                        }
                    }
                }
            }
        }
         cambiarColorPantalla(Pantalla,169);
         printf("Enviando fichero por %s.\n", cadena_Autores);
          cambiarColorPantalla(Pantalla,2);
         if(!esSondeo){
            if(flujo_log_m.is_open()){
            flujo_log_m<<"Enviando fichero por ";
            flujo_log_m<<cadena_Autores;
            flujo_log_m<<"\n";
            }
         }else{
            if(flujo_log_e.is_open()){
                flujo_log_e<<"Enviando fichero por ";
                flujo_log_e<<cadena_Autores;
                flujo_log_e<<"\n";
            }
         }

    char cadena_aux[255];
    while(!flujo_lectura.eof()&&!esEscape){//MIENTRAS QUE NO SEA FIN FICHERO Y NO SE HALLA PULSADO ESCAPE NO SE DEJA DE ENVIAR EL CUERPO FICHERO
        if (kbhit()){
            carE=getch();
            if(carE==27){//SI SE RECIBE EL CARACTER ESCAPE SE ACABA ITERACION
                esEscape=true;
            }else{
                if(carE=='\0'){
                carE=getch();
                if(carE==65){//SI SE RECIBE EL CARACTER F7 CREAMOS UN ERROR
                         contError++;
                    }
                }
            }
        }
        if(contError>0){
              if(espera==21){
                 contError--;

                if(!esSondeo){
                    enviarTramaDatos(tramaEnvio,PuertoCOM);
                     transformar(tramaPantalla,tramaEnvio);
                    printf("E %c %s %c %d\n",R1,tramaPantalla,tramaEnvio.NT,tramaEnvio.BCE);
                    if(flujo_log_m.is_open()){
                        flujo_log_m<<"E "<<R1<<" "<<tramaPantalla<<" "<<tramaEnvio.NT<<" "<<(int)tramaEnvio.BCE<<"\n";
                    }
                }else{
                    crearTramaFicheroProtocolo(tramaEnvio,PuertoCOM,cadena_aux,nt,T1);
                    enviarTramaDatos(tramaEnvio,PuertoCOM);
                    transformar(tramaPantalla,tramaEnvio);
                    printf("E %c %s %c %d\n",T1,tramaPantalla,tramaEnvio.NT,tramaEnvio.BCE);
                    if(flujo_log_e.is_open()){
                        flujo_log_e<<"E "<<T1<<" "<<tramaPantalla<<" "<<tramaEnvio.NT<<" "<<(int)tramaEnvio.BCE<<"\n";
                    }
                }
            }else{
                flujo_lectura.read (cadena_aux, 254);
                cadena_aux[flujo_lectura.gcount()] = '\0';
                if(flujo_lectura.gcount()>0){
                    cont=cont+strlen(cadena_aux);
                     if(!esSondeo){
                        crearTramaFicheroProtocolo(tramaEnvio,PuertoCOM,cadena_aux,nt,R1);
                        crearTramaError(tramaError,tramaEnvio);
                        enviarTramaDatos(tramaError,PuertoCOM);
                        transformar(tramaPantalla,tramaError);
                        printf("E %c %s %c %d\n",R1,tramaPantalla,tramaError.NT,tramaError.BCE);
                        if(flujo_log_m.is_open()){
                            flujo_log_m<<"E "<<R1<<" "<<tramaPantalla<<" "<<tramaError.NT<<" "<<(int)tramaError.BCE<<"\n";
                        }
                    }else{
                        crearTramaFicheroProtocolo(tramaEnvio,PuertoCOM,cadena_aux,nt,T1);
                        crearTramaError(tramaError,tramaEnvio);
                        enviarTramaDatos(tramaError,PuertoCOM);
                        transformar(tramaPantalla,tramaError);
                        printf("E %c %s %c %d\n",T1,tramaPantalla,tramaError.NT,tramaError.BCE);
                        if(flujo_log_e.is_open()){
                            flujo_log_e<<"E "<<T1<<" "<<tramaPantalla<<" "<<tramaError.NT<<" "<<(int)tramaError.BCE<<"\n";
                        }
                    }
                }
            }
        }else{
            flujo_lectura.read (cadena_aux, 254);
            cadena_aux[flujo_lectura.gcount()] = '\0';
            if(flujo_lectura.gcount()>0){
                cont=cont+strlen(cadena_aux);
                    if(!esSondeo){
                        crearTramaFicheroProtocolo(tramaEnvio,PuertoCOM,cadena_aux,nt,R1);
                        enviarTramaDatos(tramaEnvio,PuertoCOM);
                        transformar(tramaPantalla,tramaEnvio);
                        printf("E %c %s %c %d\n",R1,tramaPantalla,tramaEnvio.NT,tramaEnvio.BCE);
                        if(flujo_log_m.is_open()){
                        flujo_log_m<<"E "<<R1<<" "<<tramaPantalla<<" "<<tramaEnvio.NT<<" "<<(int)tramaEnvio.BCE<<"\n";
                        }
                    }else{
                        crearTramaFicheroProtocolo(tramaEnvio,PuertoCOM,cadena_aux,nt,T1);
                        enviarTramaDatos(tramaEnvio,PuertoCOM);
                        transformar(tramaPantalla,tramaEnvio);
                        printf("E %c %s %c %d\n",T1,tramaPantalla,tramaEnvio.NT,tramaEnvio.BCE);
                        if(flujo_log_e.is_open()){
                            flujo_log_e<<"E "<<T1<<" "<<tramaPantalla<<" "<<tramaEnvio.NT<<" "<<(int)tramaEnvio.BCE<<"\n";
                        }
                    }
                }
        }

        if(flujo_lectura.gcount()>0){
            espera=0;
                 while(espera!=06&&espera!=21){//ESPERA DE RESPUESTA ACK PARA SEGUIR ENVIANDO INFORMACION
                    espera=ImprimirCaracter(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
                    if(espera==06){

                            if(!esSondeo){
                                  transformar(tramaPantalla,tramaRecepcion);
                                  printf("R %c %s %c\n",R1,tramaPantalla,tramaRecepcion.NT);
                                  if(flujo_log_m.is_open()){
                                    flujo_log_m<<"R "<<R1<<" "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
                                }
                            }else{
                                     transformar(tramaPantalla,tramaRecepcion);
                                  printf("R %c %s %c\n",T1,tramaPantalla,tramaRecepcion.NT);
                                  if(flujo_log_e.is_open()){
                                    flujo_log_e<<"R "<<T1<<" "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
                                }
                            }
                }else{
                    if(espera==21){
                        if(!esSondeo){

                                  transformar(tramaPantalla,tramaRecepcion);
                                  printf("R %c %s %c\n",R1,tramaPantalla,tramaRecepcion.NT);
                                  if(flujo_log_m.is_open()){
                                    flujo_log_m<<"R "<<R1<<" "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
                                }
                            }else{
                                  transformar(tramaPantalla,tramaRecepcion);
                                  printf("R %c %s %c\n",T1,tramaPantalla,tramaRecepcion.NT);
                                  if(flujo_log_e.is_open()){
                                    flujo_log_e<<"R "<<T1<<" "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
                                }
                            }
                    }
                }
            }

    }
    }
    cambiarColorPantalla(Pantalla,7);
        EnviarCaracter(PuertoCOM,'}');//MANDAMOS CARACTER DE FIN FICHERO
        sprintf(cadena_aux,"%d",cont);
         if(!esSondeo){
                crearTramaFicheroProtocolo(tramaEnvio,PuertoCOM,cadena_aux,nt,R1);
                enviarTramaDatos(tramaEnvio,PuertoCOM);
                 transformar(tramaPantalla,tramaEnvio);
                printf("E %c %s %c %u\n",R1,tramaPantalla,tramaEnvio.NT,tramaEnvio.BCE);
                if(flujo_log_m.is_open()){
                    flujo_log_m<<"E "<<R1<<" "<<tramaPantalla<<" "<<tramaEnvio.NT<<" "<<(int)tramaEnvio.BCE<<"\n";
                }
            }else{
               crearTramaFicheroProtocolo(tramaEnvio,PuertoCOM,cadena_aux,nt,T1);
                enviarTramaDatos(tramaEnvio,PuertoCOM);
                transformar(tramaPantalla,tramaEnvio);
                printf("E %c %s %c %u\n",T1,tramaPantalla,tramaEnvio.NT,tramaEnvio.BCE);
                if(flujo_log_e.is_open()){
                    flujo_log_e<<"E "<<T1<<" "<<tramaPantalla<<" "<<tramaEnvio.NT<<" "<<(int)tramaEnvio.BCE<<"\n";
                }
            }
           espera=0;
        while(espera!=06){//ESPERA DE RESPUESTA ACK PARA SEGUIR ENVIANDO INFORMACION
                    espera=ImprimirCaracter(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
                    if(espera==06){
                            if(!esSondeo){
                                  transformar(tramaPantalla,tramaRecepcion);
                                  printf("R %c %s %c\n",R1,tramaPantalla,tramaRecepcion.NT);
                                  if(flujo_log_m.is_open()){
                                   flujo_log_m<<"R "<<R1<<" "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
                                }
                            }else{
                                  transformar(tramaPantalla,tramaRecepcion);
                                  printf("R %c %s %c\n",T1,tramaPantalla,tramaRecepcion.NT);
                                   if(flujo_log_e.is_open()){
                                    flujo_log_e<<"R "<<T1<<" "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
                                }
                            }
                }
            }
            if(esEscape){
                cambiarColorPantalla(Pantalla,169);
                printf("Fichero cancelado.\n");
                if(!esSondeo){
                    if(flujo_log_m.is_open()){
                        flujo_log_m<<"Fichero cancelado.\n";
                    }
                }else{
                    if(flujo_log_e.is_open()){
                        flujo_log_e<<"Fichero cancelado.\n";
                    }
                }
            }else{
                cambiarColorPantalla(Pantalla,169);
                printf("Fichero enviado.\n");
                if(!esSondeo){
                    if(flujo_log_m.is_open()){
                        flujo_log_m<<"Fichero enviado.\n";
                    }
                }else{
                    if(flujo_log_e.is_open()){
                        flujo_log_e<<"Fichero enviado.\n";
                    }
                }
            }
    }


    flujo_lectura.close();
}

void crearTramaFichero(Trama_C_D &tramaEnvio,HANDLE PuertoCOM,char cadena_aux[]){
    tramaEnvio.Datos[254]='\0';
    tramaEnvio.S=22;
    tramaEnvio.D='T';
    tramaEnvio.C=02;
    tramaEnvio.NT='0';
    tramaEnvio.L=strlen(cadena_aux);
    strcpy(tramaEnvio.Datos,cadena_aux);
    tramaEnvio.BCE=calculoBCE(tramaEnvio.Datos,(int)tramaEnvio.L);
}

void crearTramaDatos(char mensaje[],int cont,int &campo,Trama_C_D &tramaEnvio,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,Trama_C_D &tramaRecepcion,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m,ofstream &flujo_log_e){
    int aux=0;//CONTADOR AUXILIAR
    int longitud=0;//MANEJA LA LONGITUD DEL VECTOR D ELA TRAMA DE DATOS, EN ESTE CASO DE TD.DATOS
    int caracterContado=0;//LLEVA LA CUENTA DE LOS CARACTERES COPIADOS DE  MENSAJE A TD.DATOS
    int div=cont/254;
    tramaEnvio.S=22;
    tramaEnvio.D='T';
    tramaEnvio.C=02;
    tramaEnvio.NT='0';
    if(cont%254!=0||div==0){//SI AL DIVIDIR CONT ENTRE 254 SALE DECIMALES SIGNIFICA QUE NO ES UN NUMERO ENTERO, POR LO QUE HACE FALTA ENVIAR UNA TRAMA AMS PARA LOS CARACTERES RESTANTES
        div++;
    }
    while(aux<div){//CANTIDAD TRAMA QUE VAMOS A ENVIAR
       longitud=0;
        while(longitud<254&& !(cont-caracterContado==0)){//COMPROBAMOS QUE NO SE ESCRIBEN MAS DE 254 CARACTERES EN LA TRAMA YA QUE ES EL MAXIMO PERMITIDO Y VOLVEMOS A COMPROBAR QUE NO SE ESCRIBAN MAS CARACTERES QUE HAN SIDO ENVIADOS EN EL MENSAJE
            tramaEnvio.Datos[longitud]=mensaje[caracterContado];//COPIAMOS EN LA TRAMA DE DATOS EL MENSAJE CARACTER A CARACTER EN GRUPOS DE MAXIMO 254 CARACTERES
            longitud++;
            caracterContado++;
       }

        tramaEnvio.Datos[254]='\0';
        tramaEnvio.L=longitud;
        tramaEnvio.BCE=calculoBCE(tramaEnvio.Datos,(int)tramaEnvio.L);//CALCULAMOS EL BCE PARA COMPROBARLO LUEGO
        enviarTramaDatos(tramaEnvio, PuertoCOM);//ENVIAMOS TRAMA DE DATOS
        ImprimirCaracter(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);//LLAMAMOS A ESTE MODULO PARA SABER SI NOS HAN ENVIADO INFROMACION MIENTRAS ESTAMOS ENVIANDO NOSOTROS O VICEVERSA
        aux++;
    }
}

void enviarCuerpoFichero(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,ifstream &flujo_lectura,int &cont,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,Trama_C_D &tramaEnvio,ofstream &flujo_log,int &coloFichero,bool &esEscape,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m,ofstream &flujo_log_e){
char carE;
 esEscape=false;
  char cadena_aux[255];
    while(!flujo_lectura.eof()&&!esEscape){//MIENTRAS QUE NO SEA FIN FICHERO Y NO SE HALLA PULSADO ESCAPE NO SE DEJA DE ENVIAR EL FICHERO
        flujo_lectura.read (cadena_aux, 254);
         if(flujo_lectura.gcount()>0){
            cadena_aux[flujo_lectura.gcount()] = '\0';
            if(cadena_aux[0]!='\0')
            cont=cont+strlen(cadena_aux);
            crearTramaFichero(tramaEnvio,PuertoCOM,cadena_aux);//CREAMOS LA TRAMA DEL FICHERO

            enviarTramaDatos(tramaEnvio,PuertoCOM);// LA ENVIAMOS

            ImprimirCaracter(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);//LLAMAMOS A IMPRIMIR CARACTER PARA SABER SI ESTAMOS RECIBIENDO UNA TRAMA DE DATOS MIENTRAS ENVIAMOS
            if (kbhit()){
                carE=getch();
                if(carE==27){//SI SE RECIBE EL CARACTER ESCAPE SE ACABA ITERACION
                    esEscape=true;
                }
            }
        }
    }
}

void enviarFichero(Trama_C_D &tramaEnvio,HANDLE PuertoCOM,int &campo,Trama_C_D &tramaRecepcion,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m,ofstream &flujo_log_e){
    //TRAMA TC PARA ENVIAR Y TRAMA AUX PARA RECIBIR
    char cadena_aux[70];
    char cadena_Autores[70];
    int cont =0;
    bool esEscape;
    bool ExisteFichero=false;
    ifstream flujo_lectura;
    flujo_lectura.open("fichero-e.txt");
    if(flujo_lectura.is_open()){
        ExisteFichero=true;
        EnviarCaracter(PuertoCOM,'{');//MANDAMOS CARACTER DE INICIO FICHERO
        for(int i =0;i<3;i++){//ENVIAR LAS 3 PRIMERAS LINEAS, OSEA, LA CABECERA
          flujo_lectura.getline(cadena_aux,70);
          if(i==0){
           strcpy(cadena_Autores,cadena_aux);//EN CADENA_AUTORES SE GUARDA CADENA_AUX
          }
            crearTramaFichero(tramaEnvio,PuertoCOM,cadena_aux);
            enviarTramaDatos(tramaEnvio,PuertoCOM);
        }
        printf("Enviando fichero por %s.\n", cadena_Autores);
        if(flujo_log.is_open()){
            flujo_log<<"Enviando fichero por ";
            flujo_log<<cadena_Autores;
            flujo_log<<"\n";
        }
        enviarCuerpoFichero(campo,tramaRecepcion,PuertoCOM,Pantalla,flujo_lectura,cont,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,tramaEnvio,flujo_log,coloFichero,esEscape,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);//DESPUES DE ENVIAR LAS 3 PRIMEROAS LINEAS PROCEDEMOS A ENVIAR EL CUERPO
    }else{
        printf("ERROR: El fichero fichero-e.txt no existe\n");
        if(flujo_log.is_open()){
            flujo_log<<"ERROR: El fichero fichero-e.txt no existe\n";
        }
    }
    flujo_lectura.close();
    if(ExisteFichero){
       EnviarCaracter(PuertoCOM,'}');//MANDAMOS CARACTER DE FIN FICHERO
        sprintf(cadena_aux,"%d",cont);
        crearTramaFichero(tramaEnvio,PuertoCOM,cadena_aux);
        enviarTramaDatos(tramaEnvio,PuertoCOM);//POR ULTIMO MANDAMOS EL TAMA�O DE BYTES DEL FICHERO ENVIADO
        cambiarColorPantalla(Pantalla,169);//CAMBIAMOS EL COLOR DE LETRA Y FONDO DE PANTALLA
        if(!esEscape){
            printf("Fichero enviado.\n");
            if(flujo_log.is_open()){
                flujo_log<<"Fichero enviado.\n";
            }
        }else{
            printf("Se ha cancelado el envio del fichero\n");
            if(flujo_log.is_open()){
                    flujo_log<<"Se ha cancelado el envio del fichero\n";
            }
        }
    }
}

void maestroSondeo(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m,ofstream &flujo_log_e){
    char tramaPantalla[5];
    esSondeo=true;
    int aux=0;
    Trama_C_D tramaProtocoloEnvio;
    int espera=0;
    int cont=0;
    cambiarColorPantalla(Pantalla,9);
    tramaProtocoloEnvio.S=22;
    tramaProtocoloEnvio.D='T';
    tramaProtocoloEnvio.C=05;
    tramaProtocoloEnvio.NT='0';

    //CREACION DE TRAMA DE CONTROL Y ENVIO DE ELLA
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.S);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.D);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.C);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.NT);
    transformar(tramaPantalla,tramaProtocoloEnvio);
    printf("E T %s %c\n",tramaPantalla,tramaProtocoloEnvio.NT);
    if(flujo_log_m.is_open()){
        flujo_log_m<<"E T "<<tramaPantalla<<" "<<tramaProtocoloEnvio.NT<<"\n";
    }
     while(espera!=06){//ESPERA DE RESPUESTA ACK PARA SEGUIR ENVIANDO INFORMACION
        espera=ImprimirCaracter(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
        if(espera==06){
           transformar(tramaPantalla,tramaRecepcion);
           printf("R T %s %c\n",tramaPantalla,tramaRecepcion.NT);
            if(flujo_log_m.is_open()){
                flujo_log_m<<"R T "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
            }
        }
    }

    espera=0;
    while(aux!=1){

        espera=ImprimirCaracter(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
        if(espera==02){//ESPERA EL ENVIO DE TRAMAS DE DATOS
             transformar(tramaPantalla,tramaRecepcion);
             printf("R T %s %c %d %u\n",tramaPantalla,tramaRecepcion.NT,tramaRecepcion.BCE,calculoBCE(tramaRecepcion.Datos,tramaRecepcion.L));
             if(flujo_log_m.is_open()){
                flujo_log_m<<"R T "<<tramaPantalla<<" "<<tramaRecepcion.NT<<" "<<(int)tramaRecepcion.BCE<<" "<<(int)calculoBCE(tramaRecepcion.Datos,tramaRecepcion.L)<<"\n";
            }
             aceptacionSondeo(PuertoCOM,tramaRecepcion.NT,flujo_log_m);//ENVIO DE ACEPTACION
             cont++;
            if(cont==3){
                   cambiarColorPantalla(Pantalla,coloFichero);//CAMBIAMOS EL COLOR PREDETERMINADO POR EL QUE NOS OFRECE EL FICHERO
                    printf("Recibiendo fichero por %s.\n", cadena_AutoresRecepcion);
                    if(flujo_log_m.is_open()){
                        flujo_log_m<<"Recibiendo fichero por ";
                        flujo_log_m<<cadena_AutoresRecepcion;
                        flujo_log_m<<"\n";
                    }

            }
        }else{
            if(espera==04){//COMPROBACION DE TRAMAS DE LIBERACION
                cambiarColorPantalla(Pantalla,11);
                transformar(tramaPantalla,tramaRecepcion);
                printf("R T %s %c\n",tramaPantalla,tramaRecepcion.NT);
                if(flujo_log_m.is_open()){
                    flujo_log_m<<"R T "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
                }
                    printf("Desea el cierre de la comunicacion?\n");
                    printf("1. Si\n");
                    printf("2. No\n");
                    if(flujo_log_m.is_open()){
                        flujo_log_m<<"Desea el cierre de la comunicacion?\n";
                        flujo_log_m<<"1. Si\n";
                        flujo_log_m<<"2. No\n";
                    }
                    cin>>aux;
                    switch(aux){
                    case 1:

                        printf("Se ha elegido cierre del protocolo.\n");
                         if(flujo_log_m.is_open()){
                            flujo_log_m<<"Se ha elegido cierre del protocolo.\n";
                        }
                        aceptacionSondeo(PuertoCOM,tramaRecepcion.NT,flujo_log_m);
                        break;
                    case 2:
                       // flag=true;
                         printf("Se ha elegido no cerrar del protocolo.\n");
                         if(flujo_log_m.is_open()){
                            flujo_log_m<<"Se ha no elegido cierre del protocolo.\n";
                        }
                         tramaProtocoloEnvio.S=22;
                        tramaProtocoloEnvio.D='T';
                        tramaProtocoloEnvio.C=21;
                        tramaProtocoloEnvio.NT=tramaRecepcion.NT;

                        EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.S);
                        EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.D);
                        EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.C);
                        EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.NT);
                        transformar(tramaPantalla,tramaProtocoloEnvio);
                        printf("E T %s %c\n",tramaPantalla,tramaProtocoloEnvio.NT);
                        if(flujo_log_m.is_open()){
                            flujo_log_m<<"E T "<<tramaPantalla<<" "<<tramaProtocoloEnvio.NT<<"\n";
                        }
                        break;
                    default:
                         printf("Elija una opcion correcta\n");
                         if(flujo_log_m.is_open()){
                            flujo_log_m<<"Elija una opcion correcta\n";
                        }

                    }
            }else{
                if(espera==21){
                    transformar(tramaPantalla,tramaRecepcion);
                    printf("R T %s %c %u %u\n",tramaPantalla,tramaRecepcion.NT,tramaRecepcion.BCE,calculoBCE(tramaRecepcion.Datos,tramaRecepcion.L));
                    if(flujo_log_e.is_open()){
                        flujo_log_e<<"R T "<<tramaPantalla<<" "<<tramaRecepcion.NT<<" "<<(int)tramaRecepcion.BCE<<" "<<(int)calculoBCE(tramaRecepcion.Datos,tramaRecepcion.L)<<"\n";
                    }
                ErrorSondeo(PuertoCOM,tramaRecepcion.NT,flujo_log_e);
                }
            }
        }
     }
      cambiarColorPantalla(Pantalla,169);
     printf("Fin protocolo seleccion maestro\n");
      if(flujo_log_m.is_open()){
        flujo_log_m<<"Fin protocolo seleccion maestro\n";
    }
    esSondeo=false;
}

void maestroSeleccion(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m, ofstream &flujo_log_e){
     char tramaPantalla[5];
    Trama_C_D tramaProtocoloEnvio;
    int espera=0;
    cambiarColorPantalla(Pantalla,9);//CAMBIO DE COLOR PARA LA RECEPCION DE LAS TRAMAS
    tramaProtocoloEnvio.S=22;
    tramaProtocoloEnvio.D='R';
    tramaProtocoloEnvio.C=05;
    tramaProtocoloEnvio.NT='0';
    //CREAMOS LA TRAMA DE PROTOCOLO Y LA ENVIAMOS
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.S);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.D);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.C);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.NT);

    transformar(tramaPantalla,tramaProtocoloEnvio);
    printf("E R %s %c\n",tramaPantalla,tramaProtocoloEnvio.NT);
    if(flujo_log_m.is_open()){
            flujo_log_m<<"E R "<<tramaPantalla<<" "<<tramaProtocoloEnvio.NT<<"\n";
        }
    while(espera!=06){//ESPERAMOS LA RESPUESTA ACK PARA PODER SEGUIR ENVIANDO INFORMACION
        espera=ImprimirCaracter(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
        if(espera==06){
            transformar(tramaPantalla,tramaRecepcion);
           printf("R R %s %c\n",tramaPantalla,tramaRecepcion.NT);
           if(flujo_log_m.is_open()){
            flujo_log_m<<"R R "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
            }
        }
    }
    espera=0;
    enviarFicheroProtocolo(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
    cambiarColorPantalla(Pantalla,11);
    enviarLiberacionSeleccion(PuertoCOM,flujo_log_m);
      while(espera!=06){//ESPERAMOS LA RESPUESTA ACK PARA FINALIZAR LA TAREA
        espera=ImprimirCaracter(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
        if(espera==06){
            transformar(tramaPantalla,tramaRecepcion);
           printf("R R %s %c\n",tramaPantalla,tramaRecepcion.NT);
           if(flujo_log_m.is_open()){
            flujo_log_m<<"R R "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
            }
        }
      }
     cambiarColorPantalla(Pantalla,169);//CAMBIAMOS EL COLOR AL PREDETERMINADO POR NOSOTROS
    printf("Fin protocolo seleccion maestro\n");
     if(flujo_log_m.is_open()){
        flujo_log_m<<"Fin protocolo seleccion maestro\n";
    }

}
void soyMaestro(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m, ofstream &flujo_log_e){
if(flujo_log.is_open()){
    flujo_log.close();//CERRAMOS EL FLUJO DE LA TECLA F5
}
 esMaestro = true;
 bool eleccionMaestro;
 flujo_log_m.open("Prolog-m.txt");//ABRIMOS EL FLUJO PARA ESCRIBIR EL LOG DEL MAESTRO
 if(esEsclavo==false){//COMPROBAMOS QUE NO SE HAYA ELEGIDO ANTES ESCLAVO QUE MAESTRO, PARA NO VOLVER A ENVIAR UN MENSAJE
    esEsclavo=true;
    EnviarCaracter(PuertoCOM,'E');//ENVIAR UN MENSAJE AL OTRO USUARIO INDICANDO QUE ES ESCLAVO
 }else{
    cambiarColorPantalla(Pantalla,240);
 }
 eleccionMaestro=seleccionOpcionMaestro(flujo_log_m,Pantalla);//ELEGIMOS ENTRE SELECCION Y SONDEO
 if(eleccionMaestro){
     printf("Se ha elegido la opcion Seleccion\n");
     if(flujo_log_m.is_open()){
        flujo_log_m<<"Se ha elegido la opcion Seleccion\n";
    }
     maestroSeleccion(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
 }else{
    printf("Se ha elegido la opcion Sondeo\n");
    if(flujo_log_m.is_open()){
        flujo_log_m<<"Se ha elegido la opcion Sondeo\n";
    }
    maestroSondeo(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
 }
esEsclavo=false;
esMaestro=false;
flujo_log_m.close();
}

void esclavoSelecion(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m,ofstream &flujo_log_e){
    char tramaPantalla[5];
    int espera=0;
    int cont=0;
    while(espera!=04){

        espera=ImprimirCaracter(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
        if(espera==02){//ESPERA EL ENVIO DE TRAMAS DE DATOS
                transformar(tramaPantalla,tramaRecepcion);
             printf("R R %s %c %u %u\n",tramaPantalla,tramaRecepcion.NT,tramaRecepcion.BCE,calculoBCE(tramaRecepcion.Datos,tramaRecepcion.L));
             if(flujo_log_e.is_open()){
                flujo_log_e<<"R R "<<tramaPantalla<<" "<<tramaRecepcion.NT<<" "<<(int)tramaRecepcion.BCE<<" "<<(int)calculoBCE(tramaRecepcion.Datos,tramaRecepcion.L)<<"\n";
            }
            aceptacionSelecion(PuertoCOM,tramaRecepcion.NT,flujo_log_e);
            cont++;
            if(cont==3){
                   cambiarColorPantalla(Pantalla,coloFichero);//CAMBIAMOS EL COLOR PREDETERMINADO POR EL QUE NOS OFRECE EL FICHERO
                    printf("Recibiendo fichero por %s.\n", cadena_AutoresRecepcion);
                    if(flujo_log_e.is_open()){
                        flujo_log_e<<"Recibiendo fichero por ";
                        flujo_log_e<<cadena_AutoresRecepcion;
                        flujo_log_e<<"\n";
                    }
            }

        }else{
            if(espera==04){//COMPROBACION DE TRAMA DE FINALIZACION
                    cambiarColorPantalla(Pantalla,11);
                    transformar(tramaPantalla,tramaRecepcion);
                printf("R R %s %c\n",tramaPantalla,tramaRecepcion.NT);
                if(flujo_log_e.is_open()){
                    flujo_log_e<<"R R "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
                }
                espera=04;
                aceptacionSelecion(PuertoCOM,tramaRecepcion.NT,flujo_log_e);
            }else{
                if(espera==21){
                    transformar(tramaPantalla,tramaRecepcion);
                    printf("R R %s %c %u %u\n",tramaPantalla,tramaRecepcion.NT,tramaRecepcion.BCE,calculoBCE(tramaRecepcion.Datos,tramaRecepcion.L));
                    if(flujo_log_e.is_open()){
                        flujo_log_e<<"R R "<<tramaPantalla<<" "<<tramaRecepcion.NT<<" "<<(int)tramaRecepcion.BCE<<" "<<(int)calculoBCE(tramaRecepcion.Datos,tramaRecepcion.L)<<"\n";
                    }
                ErrorSeleccion(PuertoCOM,tramaRecepcion.NT,flujo_log_e);
                }
            }
        }
     }
      cambiarColorPantalla(Pantalla,169);
     printf("Fin protocolo seleccion esclavo\n");
     if(flujo_log_e.is_open()){
        flujo_log_e<<"Fin protocolo seleccion esclavo\n";
    }

}
void esclavoSondeo(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m,ofstream &flujo_log_e){
char tramaPantalla[5];
int espera=0;
int nt=1;
esSondeo=true;
//ENVIO DE FICHERO
enviarFicheroProtocolo(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
cambiarColorPantalla(Pantalla,11);
//PEDIMOS FINALIZAR SONDEO
liberacionSondeo(PuertoCOM,nt,flujo_log_e);

    while(espera!=06){//ESPERAMOS LA ACEPTACION PARA FINALIZAR
            espera=0;
    espera=ImprimirCaracter(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
         if(espera==06){
            transformar(tramaPantalla,tramaRecepcion);
             printf("R T %s %c\n",tramaPantalla,tramaRecepcion.NT);
             if(flujo_log_e.is_open()){
                flujo_log_e<<"R T "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
            }
         }else{
             if(espera==21){//RECEPCION NEGATIVA DE FINALIZACION SONDEO
                 transformar(tramaPantalla,tramaRecepcion);
                printf("R T %s %c\n",tramaPantalla,tramaRecepcion.NT);
                if(flujo_log_e.is_open()){
                    flujo_log_e<<"R T "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
                }
                liberacionSondeo(PuertoCOM,nt,flujo_log_e);
             }

         }
    }
    cambiarColorPantalla(Pantalla,169);
     printf("Fin protocolo sondeo esclavo\n");
      if(flujo_log_e.is_open()){
        flujo_log_e<<"Fin protocolo sondeo esclavo\n";
    }
    esSondeo=false;
}

void soyEsclavo(int &campo,Trama_C_D &tramaRecepcion,HANDLE PuertoCOM,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m, ofstream &flujo_log_e){
    if(flujo_log.is_open()){
        flujo_log.close();//CERRAMOS EL FLUJO DE LA TECLA F5
    }
    if(!esMaestro){//COMPROBAMOS QUE NO SE HAYA ELEGIDO ANTES MAESTRO QUE ESCLAVO, PARA NO VOLVER A ENVIAR UN MENSAJE
        esMaestro=true;
        EnviarCaracter(PuertoCOM,'M');
     }else{
        cambiarColorPantalla(Pantalla,240);
     }
   flujo_log_e.open("Prolog-e.txt");
   char tramaPantalla[5];
    int espera=0;
    printf("Ha seleccionado ESCLAVO:\n");
    if(flujo_log_e.is_open()){
        flujo_log_e<<"Ha seleccionado ESCLAVO\n";
    }
     esEsclavo=true;

     cambiarColorPantalla(Pantalla,9);
     while(espera!=05){//ESPERAMOS PARA SABER SI REALIZAREMOS LA OPCION DE SONDEO O SELECCION

        espera=ImprimirCaracter(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
        if(espera==05){
                if(tramaRecepcion.D=='R'){//SELECCION
                    transformar(tramaPantalla,tramaRecepcion);
                    printf("R R %s %c\n",tramaPantalla,tramaRecepcion.NT);
                    aceptacionSelecion(PuertoCOM,tramaRecepcion.NT,flujo_log_e);
                    if(flujo_log_e.is_open()){
                        flujo_log_e<<"R R "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
                    }
                    esclavoSelecion(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
                }else{
                    if(tramaRecepcion.D=='T'){//SONDEO
                        transformar(tramaPantalla,tramaRecepcion);
                        printf("R T %s %c\n",tramaPantalla,tramaRecepcion.NT);
                        if(flujo_log_e.is_open()){
                            flujo_log_e<<"R T "<<tramaPantalla<<" "<<tramaRecepcion.NT<<"\n";
                        }
                        aceptacionSondeo(PuertoCOM,tramaRecepcion.NT,flujo_log_e);
                        esclavoSondeo(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
                        espera=05;
                    }
                }
        }
     }
    esMaestro=false;
    esEsclavo=false;
    flujo_log_e.close();
}

void EnviarCaracter(char carE,int &cont,char mensaje[],Trama_C_D &tramaEnvio,HANDLE PuertoCOM,int &campo,Trama_C_D &tramaRecepcion,HANDLE Pantalla,bool &esFichero, bool &finFichero,int &cont_Fichero,char cadena_AutoresRecepcion[],ofstream &flujo_escritura,ofstream &flujo_log,int &coloFichero,bool &estaEnProtocolo,bool &esMaestro,bool &esEsclavo,bool &esSondeo,ofstream &flujo_log_m, ofstream &flujo_log_e){
        cambiarColorPantalla(Pantalla,169);//CAMBIAMOS EL COLOR E LETRA Y FONDO DE PANTALLA
        switch(carE){ //COMPARAMOS LAS OPCIONES DADAS PARA AVERIGUAR QUE CARACTER SE HA PULSADO

        case '\0':
            carE = getch();
            switch(carE){
            case 59://CASO DE F1, ENVIA TRAMA DE DATOS
                mensaje[cont]='\n';
                cont++;
                 if(flujo_log.is_open()){
                    flujo_log.write(mensaje,cont);
                }
                crearTramaDatos(mensaje,cont,campo,tramaEnvio,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,tramaRecepcion,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);//TRANSFORMA EL MENSAJE EN UA TRAMA DE DATOS Y LA ENVIA
                cont=0;
                printf("\n");
                break;
            case 60://CASO DE F2, ENVIA TRAMA DE CONTROL
                crearTramaControl(tramaEnvio,PuertoCOM,flujo_log);
                ImprimirCaracter(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
                break;
            case 61://CASO DE F3, ENVIO DE FICHERO
                enviarFichero(tramaEnvio,PuertoCOM,campo,tramaRecepcion,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
                break;
            case 63://CASO DE F5, USO DE FICHERO LOG
                printf("Se ha pulsado F5, se abre fichero log.txt en esta consola\n");
                flujo_log.open("log.txt");
                break;
            case 64://CASO DE F6, PROTOCOLO MAESTRO_ESCLAVO

                    if(elegirMaestro_Esclavo()){
                        soyMaestro(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
                    }else{
                        soyEsclavo(campo,tramaRecepcion,PuertoCOM,Pantalla,esFichero,finFichero,cont_Fichero,cadena_AutoresRecepcion,flujo_escritura,flujo_log,coloFichero,esMaestro,esEsclavo,esSondeo,flujo_log_m,flujo_log_e);
                    }
                break;
            }
        break;
        case 8: // CASO DE DELETE
          if(cont>0){//SI ES MENOR QUE 0 HACEMOS QUE EL CONTADOR NO BAJE PARA QUE NO DE ERROR
                SetConsoleTextAttribute(Pantalla,15);
                printf("\b");
                printf(" ");
                printf("\b");
                cont--;
          SetConsoleTextAttribute(Pantalla,169);
            }
        break;
        case 13://CASO DE ENTER
            if(cont<800){
                printf("\n");
                if(flujo_log.is_open()){
                    flujo_log<<"\n";
                }
                mensaje[cont]='\n';
                cont++;
            }
        break;
        default:// TODOS LOS DEMAS CARACTERES
            if(cont<800){
                printf("%c", carE);
                mensaje[cont]=carE;
                cont++;
            }
        }
}
