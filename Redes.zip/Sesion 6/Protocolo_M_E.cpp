//AUTORES: JUAN ROMO GONZ�LEZ Y JAIME GONZ�LEZ NAVARE�O
//GRUPO L1 LUNES 8:30
#include "Protocolo_M_E.h"

void enviarLiberacionSeleccion(HANDLE PuertoCOM,ofstream &flujo_log_m){
     char tramaPantalla[5];
    Trama_C_D tramaProtocoloCierre;
    tramaProtocoloCierre.S=22;
    tramaProtocoloCierre.D='R';
    tramaProtocoloCierre.C=04;
    tramaProtocoloCierre.NT='0';


    EnviarCaracter(PuertoCOM,tramaProtocoloCierre.S);
    EnviarCaracter(PuertoCOM,tramaProtocoloCierre.D);
    EnviarCaracter(PuertoCOM,tramaProtocoloCierre.C);
    EnviarCaracter(PuertoCOM,tramaProtocoloCierre.NT);
     transformar(tramaPantalla,tramaProtocoloCierre);
    printf("E R %s %c\n",tramaPantalla,tramaProtocoloCierre.NT);
     if(flujo_log_m.is_open()){
        flujo_log_m<<"E R "<<tramaPantalla<<" "<<tramaProtocoloCierre.NT<<"\n";
    }
}

void  aceptacionSelecion(HANDLE PuertoCOM,unsigned char nt,ofstream &flujo_log_e){
    char tramaPantalla[5];
     Trama_C_D tramaProtocoloEnvio;
    tramaProtocoloEnvio.S=22;
    tramaProtocoloEnvio.D='R';
    tramaProtocoloEnvio.C=06;


        tramaProtocoloEnvio.NT=nt;


    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.S);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.D);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.C);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.NT);
    transformar(tramaPantalla,tramaProtocoloEnvio);
    printf("E R %s %c\n",tramaPantalla,tramaProtocoloEnvio.NT);
    if(flujo_log_e.is_open()){
        flujo_log_e<<"E R "<<tramaPantalla<<" "<<tramaProtocoloEnvio.NT<<"\n";
    }
 }

void aceptacionSondeo(HANDLE PuertoCOM,unsigned char nt,ofstream &flujo_log_e){
    char tramaPantalla[5];
    Trama_C_D tramaProtocoloEnvio;
    tramaProtocoloEnvio.S=22;
    tramaProtocoloEnvio.D='T';
    tramaProtocoloEnvio.C=06;
    tramaProtocoloEnvio.NT=nt;


    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.S);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.D);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.C);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.NT);
     transformar(tramaPantalla,tramaProtocoloEnvio);
    printf("E T %s %c\n",tramaPantalla,tramaProtocoloEnvio.NT);
     if(flujo_log_e.is_open()){
        flujo_log_e<<"E T "<<tramaPantalla<<" "<<tramaProtocoloEnvio.NT<<"\n";
    }
}


void liberacionSondeo(HANDLE PuertoCOM,int &nt,ofstream &flujo_log_e){
    char tramaPantalla[5];
    Trama_C_D tramaProtocoloCierre;
    tramaProtocoloCierre.S=22;
    tramaProtocoloCierre.D='R';
    tramaProtocoloCierre.C=04;
    tramaProtocoloCierre.NT='0';
if(nt==0){
        nt=1;
        tramaProtocoloCierre.NT='1';
    }else{
        nt=0;
        tramaProtocoloCierre.NT='0';
    }

    EnviarCaracter(PuertoCOM,tramaProtocoloCierre.S);
    EnviarCaracter(PuertoCOM,tramaProtocoloCierre.D);
    EnviarCaracter(PuertoCOM,tramaProtocoloCierre.C);
    EnviarCaracter(PuertoCOM,tramaProtocoloCierre.NT);
    transformar(tramaPantalla,tramaProtocoloCierre);
    printf("E T %s %c\n",tramaPantalla,tramaProtocoloCierre.NT);
    if(flujo_log_e.is_open()){
        flujo_log_e<<"E T "<<tramaPantalla<<" "<<tramaProtocoloCierre.NT<<"\n";
    }
}


void ErrorSeleccion(HANDLE PuertoCOM,unsigned char nt,ofstream &flujo_log_e){
 char tramaPantalla[5];
     Trama_C_D tramaProtocoloEnvio;
    tramaProtocoloEnvio.S=22;
    tramaProtocoloEnvio.D='R';
    tramaProtocoloEnvio.C=21;


        tramaProtocoloEnvio.NT=nt;


    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.S);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.D);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.C);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.NT);
    transformar(tramaPantalla,tramaProtocoloEnvio);
    printf("E R %s %c\n",tramaPantalla,tramaProtocoloEnvio.NT);
    if(flujo_log_e.is_open()){
        flujo_log_e<<"E R "<<tramaPantalla<<" "<<tramaProtocoloEnvio.NT<<"\n";
    }
 }
void ErrorSondeo(HANDLE PuertoCOM,unsigned char nt,ofstream &flujo_log_e){
 char tramaPantalla[5];
     Trama_C_D tramaProtocoloEnvio;
    tramaProtocoloEnvio.S=22;
    tramaProtocoloEnvio.D='T';
    tramaProtocoloEnvio.C=21;


        tramaProtocoloEnvio.NT=nt;


    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.S);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.D);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.C);
    EnviarCaracter(PuertoCOM,tramaProtocoloEnvio.NT);
    transformar(tramaPantalla,tramaProtocoloEnvio);
    printf("E T %s %c\n",tramaPantalla,tramaProtocoloEnvio.NT);
    if(flujo_log_e.is_open()){
        flujo_log_e<<"E T "<<tramaPantalla<<" "<<tramaProtocoloEnvio.NT<<"\n";
    }
 }





